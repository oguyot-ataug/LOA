import React, { useState } from 'react';
import { LogEntry } from '../types';
import { X } from 'lucide-react';

interface LogFormProps {
  onAdd: (log: LogEntry) => void;
  onClose: () => void;
}

export default function LogForm({ onAdd, onClose }: LogFormProps) {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [km, setKm] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (date && km) {
      onAdd({
        id: crypto.randomUUID(),
        date: date,
        km: parseInt(km, 10),
      });
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900/90 backdrop-blur-2xl border border-white/10 rounded-[32px] shadow-2xl w-full max-w-sm overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <div className="px-6 py-6 border-b border-white/10 flex justify-between items-center">
          <h3 className="text-xl font-bold text-white">Ajouter un relevé</h3>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-white/10 text-slate-400 transition-colors">
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div>
            <label htmlFor="date" className="block text-sm font-medium text-slate-300 mb-1">Date</label>
            <input
              type="date"
              id="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-white placeholder-slate-500 transition-colors [color-scheme:dark]"
            />
          </div>
          
          <div>
            <label htmlFor="km" className="block text-sm font-medium text-slate-300 mb-1">Kilométrage actuel (affiché au compteur)</label>
            <input
              type="number"
              id="km"
              value={km}
              onChange={(e) => setKm(e.target.value)}
              required
              min="0"
              autoFocus
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-white transition-colors"
            />
          </div>
          
          <div className="pt-4 flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 px-4 bg-transparent border border-white/20 text-slate-300 hover:text-white hover:bg-white/5 font-semibold rounded-2xl transition-all"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="flex-1 py-3 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-2xl shadow-lg shadow-indigo-600/30 transition-all focus:ring-2 focus:ring-offset-2 focus:ring-offset-[#0f172a] focus:ring-indigo-500"
            >
              Ajouter
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
