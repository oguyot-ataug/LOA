import React, { useState } from 'react';
import { ContractData } from '../types';

interface SettingsProps {
  initialData?: ContractData;
  onSave: (data: ContractData) => void;
}

export default function Settings({ initialData, onSave }: SettingsProps) {
  const [formData, setFormData] = useState<Partial<ContractData>>(
    initialData || {
      startDate: new Date().toISOString().split('T')[0],
      durationMonths: 36,
      totalKm: 30000,
      penaltyPerKm: 0.10,
    }
  );

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'startDate' ? value : parseFloat(value) || 0
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.startDate && formData.durationMonths && formData.totalKm) {
      onSave(formData as ContractData);
    }
  };

  return (
    <div className="max-w-md mx-auto relative pt-12">
      <div className="bg-white/10 backdrop-blur-2xl border border-white/20 p-6 sm:p-8 rounded-[32px] shadow-lg shadow-black/20">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-white tracking-tight">Configuration de la LOA</h2>
          <p className="text-slate-400 mt-1 text-sm">Entrez les détails de votre contrat pour commencer le suivi.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label htmlFor="startDate" className="block text-sm font-medium text-slate-300 mb-1">Date de début</label>
            <input
              type="date"
              id="startDate"
              name="startDate"
              value={formData.startDate?.split('T')[0] || ''}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-white placeholder-slate-500 transition-colors [color-scheme:dark]"
            />
          </div>

          <div>
            <label htmlFor="durationMonths" className="block text-sm font-medium text-slate-300 mb-1">Durée (mois)</label>
            <input
              type="number"
              id="durationMonths"
              name="durationMonths"
              value={formData.durationMonths || ''}
              onChange={handleChange}
              required
              min="1"
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-white transition-colors"
            />
          </div>

          <div>
            <label htmlFor="totalKm" className="block text-sm font-medium text-slate-300 mb-1">Kilométrage total autorisé</label>
            <input
              type="number"
              id="totalKm"
              name="totalKm"
              value={formData.totalKm || ''}
              onChange={handleChange}
              required
              min="1"
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-white transition-colors"
            />
          </div>

          <div>
            <label htmlFor="penaltyPerKm" className="block text-sm font-medium text-slate-300 mb-1">Pénalité par km suppl. (€)</label>
            <input
              type="number"
              id="penaltyPerKm"
              name="penaltyPerKm"
              value={formData.penaltyPerKm || ''}
              onChange={handleChange}
              required
              min="0"
              step="0.01"
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-white transition-colors"
            />
          </div>

          <button
            type="submit"
            className="w-full mt-4 py-3 px-6 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-2xl shadow-lg shadow-indigo-600/30 transition-all focus:ring-2 focus:ring-offset-2 focus:ring-offset-[#0f172a] focus:ring-indigo-500"
          >
            Enregistrer
          </button>
        </form>
      </div>
    </div>
  );
}
