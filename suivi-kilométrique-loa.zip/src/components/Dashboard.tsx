import React, { useState, useMemo } from 'react';
import { ContractData, LogEntry } from '../types';
import { differenceInDays, addMonths, parseISO, format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Settings, Plus, TrendingUp, AlertTriangle, CheckCircle2, Car } from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceArea
} from 'recharts';

interface DashboardProps {
  contract: ContractData;
  logs: LogEntry[];
  onAddLog: () => void;
  onEditSettings: () => void;
  onDeleteLog: (id: string) => void;
}

export default function Dashboard({ contract, logs, onAddLog, onEditSettings, onDeleteLog }: DashboardProps) {
  const stats = useMemo(() => {
    const startDate = parseISO(contract.startDate);
    const endDate = addMonths(startDate, contract.durationMonths);
    const totalDays = differenceInDays(endDate, startDate);
    const dailyAllowed = contract.totalKm / totalDays;
    
    const sortedLogs = [...logs].sort((a, b) => parseISO(a.date).getTime() - parseISO(b.date).getTime());
    const latestLog = sortedLogs.length > 0 ? sortedLogs[sortedLogs.length - 1] : null;
    
    let currentDifference = 0;
    let projectedEndKm = 0;
    let estimatedPenalty = 0;
    
    if (latestLog) {
      const logDate = parseISO(latestLog.date);
      const daysSinceStart = differenceInDays(logDate, startDate);
      const targetAtLogDate = dailyAllowed * daysSinceStart;
      
      currentDifference = latestLog.km - Math.round(targetAtLogDate);
      
      if (daysSinceStart > 0) {
        const currentDailyAvg = latestLog.km / daysSinceStart;
        projectedEndKm = Math.round(currentDailyAvg * totalDays);
      } else {
        projectedEndKm = latestLog.km;
      }
      
      const projectedOver = projectedEndKm - contract.totalKm;
      if (projectedOver > 0) {
        estimatedPenalty = projectedOver * contract.penaltyPerKm;
      }
    }

    const chartData = [];
    
    // Add start point
    chartData.push({
      date: startDate.getTime(),
      target: 0,
      actual: 0
    });

    // Add log points
    sortedLogs.forEach(log => {
      const logTs = parseISO(log.date).getTime();
      const days = differenceInDays(parseISO(log.date), startDate);
      // Avoid duplicating start point
      if (logTs !== startDate.getTime()) {
        chartData.push({
          date: logTs,
          target: Math.round(dailyAllowed * days),
          actual: log.km
        });
      }
    });

    // Add end point for target line
    chartData.push({
      date: endDate.getTime(),
      target: contract.totalKm,
      actual: null
    });

    return {
      startDate,
      endDate,
      totalDays,
      dailyAllowed,
      latestLog,
      currentDifference,
      projectedEndKm,
      estimatedPenalty,
      chartData,
      sortedLogs: [...sortedLogs].reverse() // Reversed for history list
    };
  }, [contract, logs]);

  const isOverLimit = stats.currentDifference > 0;
  const isProjectedOver = stats.projectedEndKm > contract.totalKm;

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      {/* Header */}
      <div className="flex items-center justify-between bg-white/5 backdrop-blur-2xl border border-white/10 p-6 sm:p-8 rounded-[32px] shadow-lg shadow-black/20">
        <div>
          <h1 className="text-3xl font-bold text-white tracking-tight flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/30">
              <Car className="text-white w-6 h-6" />
            </div>
            Suivi LOA
          </h1>
          <p className="text-sm text-slate-400 mt-2">
            Du {format(stats.startDate, 'dd MMM yyyy', { locale: fr })} au {format(stats.endDate, 'dd MMM yyyy', { locale: fr })}
          </p>
        </div>
        <button
          onClick={onEditSettings}
          className="p-3 text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-2xl transition-all border border-white/10 shadow-lg shadow-black/20"
          title="Paramètres"
        >
          <Settings size={20} />
        </button>
      </div>

      {/* Primary Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Current Status */}
        <div className="bg-white/10 backdrop-blur-2xl border border-white/20 p-6 rounded-[32px] flex flex-col justify-between">
          <div>
            <p className="text-sm uppercase tracking-widest font-semibold text-slate-400 mb-2">Situation actuelle</p>
            {stats.latestLog ? (
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-extrabold text-white">
                  {stats.currentDifference > 0 ? '+' : ''}{stats.currentDifference.toLocaleString('fr-FR')}
                </span>
                <span className="text-xl text-slate-400">km</span>
              </div>
            ) : (
              <span className="text-xl font-medium text-slate-400">Aucun relevé</span>
            )}
          </div>
          <div className="mt-4 flex items-center text-sm font-medium">
            {stats.latestLog ? (
               isOverLimit ? (
                <span className="text-red-400 flex items-center justify-between gap-1 bg-red-500/10 border border-red-500/20 px-3 py-2 rounded-xl w-full">
                  <span>En retard (surkilométrage)</span>
                  <AlertTriangle size={18} />
                </span>
              ) : (
                <span className="text-emerald-400 flex items-center justify-between gap-1 bg-emerald-500/10 border border-emerald-500/20 px-3 py-2 rounded-xl w-full">
                  <span>+ {Math.abs(stats.currentDifference).toLocaleString('fr-FR')} km d'avance</span>
                  <CheckCircle2 size={18} />
                </span>
              )
            ) : (
              <span className="text-slate-400">Commencez à logger</span>
            )}
          </div>
        </div>

        {/* Projection */}
        <div className="bg-indigo-600/20 backdrop-blur-2xl border border-indigo-500/30 p-6 rounded-[32px] flex flex-col justify-between">
          <div>
            <p className="text-sm uppercase tracking-widest font-semibold text-indigo-200 mb-2">Simulation au Rendu</p>
            {stats.latestLog ? (
              <div className="flex flex-col gap-1">
                <span className="text-4xl font-extrabold text-white">
                  {stats.projectedEndKm.toLocaleString('fr-FR')} <span className="text-xl text-indigo-200 font-normal">km</span>
                </span>
                <span className="text-sm text-indigo-300/80">Projeté avec votre usage actuel</span>
              </div>
            ) : (
              <span className="text-xl font-medium text-slate-400">-</span>
            )}
          </div>
          <div className="mt-4 flex items-center justify-between text-white border-t border-indigo-500/20 pt-4">
            <span className="text-sm font-semibold text-indigo-100">Limite contrat :</span>
            <span className="text-sm font-bold px-3 py-1 bg-white/10 rounded-xl">{contract.totalKm.toLocaleString()} km</span>
          </div>
        </div>

        {/* Penalty */}
        <div className="bg-white/5 backdrop-blur-2xl border border-white/10 p-6 rounded-[32px] flex flex-col justify-between">
           <div>
            <p className="text-sm uppercase tracking-widest font-semibold text-slate-400 mb-2">Pénalité estimée</p>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-extrabold text-white">
                {stats.estimatedPenalty.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
              </span>
            </div>
          </div>
          {stats.estimatedPenalty > 0 && (
             <div className="mt-4 text-xs font-medium text-red-300 bg-red-500/10 border border-red-500/20 px-3 py-2 rounded-xl">
               Lié au dépassement projeté
             </div>
          )}
        </div>
      </div>

      {/* Chart */}
      <div className="bg-white/5 backdrop-blur-2xl border border-white/10 p-6 sm:p-8 rounded-[32px]">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-8 gap-4">
          <h2 className="text-xl font-semibold text-white">Suivi de l'utilisation</h2>
          <div className="flex gap-4 text-sm">
            <div className="flex items-center gap-2 text-slate-400">
              <span className="w-3 h-3 bg-white/20 rounded-full"></span> Limite autorisée
            </div>
            <div className="flex items-center gap-2 text-indigo-400">
              <span className="w-3 h-3 bg-indigo-500 rounded-full"></span> Réel / Projection
            </div>
          </div>
        </div>
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={stats.chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="8 4" vertical={false} stroke="rgba(255,255,255,0.1)" />
              <XAxis 
                dataKey="date" 
                type="number" 
                domain={['dataMin', 'dataMax']}
                tickFormatter={(unixTime) => format(new Date(unixTime), 'MMM yy', { locale: fr })}
                stroke="#64748b"
                tick={{fill: '#64748b', fontSize: 12, fontWeight: 500}}
                axisLine={false}
                tickLine={false}
                dy={10}
              />
              <YAxis 
                stroke="#64748b"
                tick={{fill: '#64748b', fontSize: 12, fontWeight: 500}}
                axisLine={false}
                tickLine={false}
                tickFormatter={(value) => `${(value/1000).toFixed(0)}k`}
                dx={-10}
              />
              <Tooltip 
                labelFormatter={(label) => format(new Date(label), 'dd MMMM yyyy', { locale: fr })}
                formatter={(value: number, name: string) => [
                  `${value.toLocaleString('fr-FR')} km`, 
                  name === 'target' ? 'Cible (idéal)' : 'Réel'
                ]}
                contentStyle={{ 
                  borderRadius: '16px', 
                  border: '1px solid rgba(255,255,255,0.2)', 
                  background: 'rgba(30, 41, 59, 0.8)',
                  backdropFilter: 'blur(12px)',
                  color: 'white',
                  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.3)' 
                }}
                itemStyle={{ color: 'white' }}
              />
              <Line 
                type="monotone" 
                dataKey="target" 
                stroke="rgba(255,255,255,0.2)" 
                strokeWidth={2} 
                strokeDasharray="8 4" 
                dot={false}
                name="target"
                isAnimationActive={false}
              />
              <Line 
                type="monotone" 
                dataKey="actual" 
                stroke="#6366f1" 
                strokeWidth={4}
                dot={{r: 4, strokeWidth: 2, fill: '#6366f1', stroke: '#0f172a'}}
                activeDot={{r: 6, strokeWidth: 0, fill: '#a855f7'}}
                name="actual"
                connectNulls
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* History */}
      <div className="bg-white/5 backdrop-blur-2xl rounded-[32px] shadow-lg border border-white/10 overflow-hidden">
        <div className="px-6 py-6 border-b border-white/10 flex justify-between items-center bg-white/5">
          <h2 className="text-xl font-semibold text-white">Historique des relevés</h2>
          <button
            onClick={onAddLog}
            className="flex items-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-2xl shadow-lg shadow-indigo-600/30 transition-all focus:ring-2 focus:ring-offset-2 focus:ring-offset-[#0f172a] focus:ring-indigo-500"
          >
            <Plus size={18} /> Saisir Kilométrage
          </button>
        </div>
        <div className="divide-y divide-white/5">
          {stats.sortedLogs.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-sm">
              Aucun relevé pour le moment. Ajoutez votre premier kilométrage !
            </div>
          ) : (
            stats.sortedLogs.map((log) => (
              <div key={log.id} className="p-4 sm:px-6 flex items-center justify-between hover:bg-white/5 transition-colors">
                <div className="flex flex-col">
                  <span className="font-bold text-white text-lg">{log.km.toLocaleString('fr-FR')} km</span>
                  <span className="text-sm text-slate-400">{format(parseISO(log.date), 'dd MMMM yyyy', { locale: fr })}</span>
                </div>
                <button
                  onClick={() => onDeleteLog(log.id)}
                  className="p-3 text-slate-400 hover:text-red-400 transition-colors rounded-xl hover:bg-red-400/10"
                  title="Supprimer ce relevé"
                >
                  <AlertTriangle size={18} className="sr-only" />
                  <span className="text-sm font-medium">Supprimer</span>
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
