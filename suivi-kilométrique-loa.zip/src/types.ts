export interface ContractData {
  startDate: string;
  durationMonths: number;
  totalKm: number;
  penaltyPerKm: number;
}

export interface LogEntry {
  id: string;
  date: string;
  km: number;
}
