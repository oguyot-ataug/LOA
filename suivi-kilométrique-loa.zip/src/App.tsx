import React, { useState, useEffect } from 'react';
import { ContractData, LogEntry } from './types';
import Settings from './components/Settings';
import Dashboard from './components/Dashboard';
import LogForm from './components/LogForm';

const STORAGE_KEY_CONTRACT = 'loa_tracker_contract';
const STORAGE_KEY_LOGS = 'loa_tracker_logs';

export default function App() {
  const [isLoaded, setIsLoaded] = useState(false);
  const [contract, setContract] = useState<ContractData | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  
  const [isEditingSettings, setIsEditingSettings] = useState(false);
  const [isAddingLog, setIsAddingLog] = useState(false);

  useEffect(() => {
    const savedContract = localStorage.getItem(STORAGE_KEY_CONTRACT);
    const savedLogs = localStorage.getItem(STORAGE_KEY_LOGS);

    if (savedContract) {
      try {
        setContract(JSON.parse(savedContract));
      } catch (e) {
        console.error('Failed to parse contract data', e);
      }
    }
    
    if (savedLogs) {
      try {
        setLogs(JSON.parse(savedLogs));
      } catch (e) {
        console.error('Failed to parse logs data', e);
      }
    }
    
    setIsLoaded(true);
  }, []);

  const handleSaveContract = (data: ContractData) => {
    setContract(data);
    localStorage.setItem(STORAGE_KEY_CONTRACT, JSON.stringify(data));
    setIsEditingSettings(false);
  };

  const handleAddLog = (log: LogEntry) => {
    const newLogs = [...logs, log];
    setLogs(newLogs);
    localStorage.setItem(STORAGE_KEY_LOGS, JSON.stringify(newLogs));
  };
  
  const handleDeleteLog = (id: string) => {
    if (window.confirm("Êtes-vous sûr de vouloir supprimer ce relevé ?")) {
      const newLogs = logs.filter(l => l.id !== id);
      setLogs(newLogs);
      localStorage.setItem(STORAGE_KEY_LOGS, JSON.stringify(newLogs));
    }
  };

  if (!isLoaded) {
    return <div className="min-h-screen bg-[#0f172a] bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-indigo-500/20 via-slate-900 to-slate-950 flex items-center justify-center text-slate-400">Chargement...</div>;
  }

  return (
    <div className="min-h-screen bg-[#0f172a] bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-indigo-500/20 via-slate-900 to-slate-950 text-white font-sans selection:bg-indigo-500/30 p-4 sm:p-6 lg:p-8">
      {(!contract || isEditingSettings) ? (
        <div>
          {contract && isEditingSettings && (
            <button 
              onClick={() => setIsEditingSettings(false)}
              className="mb-4 text-sm font-medium text-slate-400 hover:text-white transition-colors"
            >
              &larr; Retour au tableau de bord
            </button>
          )}
          <Settings 
            initialData={contract || undefined} 
            onSave={handleSaveContract} 
          />
        </div>
      ) : (
        <Dashboard 
          contract={contract} 
          logs={logs} 
          onAddLog={() => setIsAddingLog(true)} 
          onEditSettings={() => setIsEditingSettings(true)}
          onDeleteLog={handleDeleteLog}
        />
      )}

      {isAddingLog && (
        <LogForm 
          onAdd={handleAddLog} 
          onClose={() => setIsAddingLog(false)} 
        />
      )}
    </div>
  );
}
